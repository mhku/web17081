<?php
header("Content-Type:application/json");
//require_once("../../init.php");
require_once("../../controllers/product.controller.php");
getProductsByKw();