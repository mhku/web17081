<?php
require("../../controllers/user.controller.php");
logout();