<?php
require("../../controllers/user.controller.php");
echo json_encode(isLogin());