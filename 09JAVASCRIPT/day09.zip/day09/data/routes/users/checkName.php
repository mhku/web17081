<?php
require("../../controllers/user.controller.php");
if(checkName()) echo "true";
else echo "false";