<?php
require("../../controllers/user.controller.php");
     //data/
register();