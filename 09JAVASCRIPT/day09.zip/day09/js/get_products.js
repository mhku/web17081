function loadProducts(pno=0){
    ajax({
        type:"get",
        url:"data/routes/products/products.php",
        data:location.search.slice(1)+"&pno="+pno
    }).then(output=>{
        console.log(output);
        var data=output.data;
        var html="";
        for(var p of data){
            html+=`
                <li>
                    <a href="product-details.html?lid=${p.lid}">
                      <img src="${p.md}" alt="">
                    </a>
                    <p>
                      ¥<span class="price">${p.price}</span>
                      <a href="product-details.html?lid=${p.lid}">${p.title}</a>
                    </p>
                    <div>
                      <span class="reduce">-</span>
                      <input type="text" value="1">
                      <span class="add">+</span>
                      <a href="javascript:;" class="addCart">加入购物车</a>
                    </div>
                  </li>
            `;
        }
        document.querySelector("#show-list").innerHTML=html;
        var pageCount=output.pageCount;
        var pageNo=output.pageNo;
        var html=`<a href="javascript:;" class="previous disabled">上一页</a>`;
        for(var i=1;i<=pageCount;i++){
            html+=`
                 <a href="javascript:;">${i}</a>
            `;
        }
        html+=`<a href="javascript:;" class="next">下一页</a> `;
        var divPages=document.getElementById("pages");
        divPages.innerHTML=html;
        divPages.children[pageNo+1].className="current";
        divPages.onclick=e=>{
            if(e.target.nodeName=="A"){

                var a=e.target;
                if(a!=divPages.children[0]&&a!=divPages.lastElementChild){
                    if(a.className!="current"){
                        var pno=a.innerHTML-1;
                        loadProducts(pno);
                    }
                }else{//否则a.className.indexOf("disabled")==-1
                    //如果class不以disabled结尾
                    if(!a.className.endsWith("disabled")){
                        //如果class以next开发
                        if(a.className.startsWith("next")){
                            //在divPages下查找class为current的a
                           var curr= divPages.querySelector(".current");
                            ////清除current的class
                            //curr.className="";
                            ////为current的下一个兄弟元素加class current
                            //curr.nextElementSibling.className="current";
                            //重新加载商品列表传入current的内容作为pno
                            loadProducts(curr.innerHTML);
                        }
                    }
                 }
            }
        }
    })
}
(()=>{
    loadProducts();
})();